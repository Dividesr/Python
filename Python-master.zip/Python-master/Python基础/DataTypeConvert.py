
a = int('123') # 转换为一个整数
print(type(a))

b = float('123.456')
print(type(b))

c = complex(2, 4)
print(c)

s = str(c)
print(s)

print(chr(65))
print(ord('A'))