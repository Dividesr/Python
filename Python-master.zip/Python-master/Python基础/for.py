
l1 = ['wangh', 'kongl', 'wangjy']

for name in l1:
    print(name)

l2 = range(10)
for i in l2:
    print(i)