
x, y, z = 10, 5, 5
if x > y:
    print('x > y')
elif x < y:
    print('x < y')
else:
    print('x = y')